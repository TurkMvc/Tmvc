<?php

namespace App\Controllers;


class BaseController
{
    
}