<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>TurkMvc E-Commerce Store - @yield('title')</title>
</head>
<body>
	
</body>
</html>